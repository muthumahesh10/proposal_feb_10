import { Component, OnInit } from '@angular/core';
import { ProposalService } from '../proposal.service';
import { Workbook } from 'exceljs';
import { Router } from '@angular/router';
import { FileSaverService } from "ngx-filesaver";
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
public page_name:any;
  constructor(private router:Router) {
  
   }

  ngOnInit(): void {
  }
  project()
  {
    this.router.navigateByUrl('/page')
  }
moveHome()
{
  this.page_name='list'
}
  
}
