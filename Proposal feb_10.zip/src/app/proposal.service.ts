import { Injectable } from '@angular/core';
import { environment } from './../environments/environment';
import { HttpClient } from '@angular/common/http';
import { provideRoutes } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProposalService {
  root:any;
  constructor(private http: HttpClient) { 
    this.root= environment.apiURL;
  }
 

  loginUser(user_name:any,pword:any)
  {
    console.log(user_name)
    return this.http.get(this.root+'/proposal/loginuser/'+user_name+'/'+pword);
  }

  resetPassword(emailid:any)
  {
    return this.http.get(this.root+'/proposal/resetpassword/'+emailid);
  }
  // loginWithGoogle(emailid:any,uname:any) 
  // {
  //   return this.http.get(this.root+'/well/loginwithgoogle/'+emailid+'/'+uname);
  // } 

  // saveProject(body:any)
  // {
  //   return this.http.get(this.root+'/proposal/saveproject'+body)
  // }


  getInfoValue(pid:any)
  {
    return this.http.get(this.root+'/proposal/getinfovalue/'+pid);
  }
  
  // service(body:any)
  // {
  //   return this.http.post(this.root+'/proposal/scopeService',body)
  // }
  
  // getUpsProjectInfo(pid:any)
  // {
  //   console.log(pid)
  //   return this.http.get(this.root+'/proposal/getupsprojectinfo/'+pid);
  // }

  saveCoreProjectInfo(pid:any,bulkquery:any)
  {
    let body = JSON.stringify(bulkquery);
    let url=this.root+'/proposal/savecoreprojectinfo/'+pid;
    return this.http.post(url, body);
  }

  starRating(pid:any)
  {
    return this.http.get(this.root +'/proposal/starRating/'+pid)
  }

}
