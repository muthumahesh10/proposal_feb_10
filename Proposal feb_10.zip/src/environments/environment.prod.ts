export const environment = {
  production: true,
  apiURL:"https://backend.thogupu.com"
};
